package com.yash.oopsdemo2;

    class Person {
	String name;
    double salary;
    String year;
    String insurance ;
	public String getName() {

      return name;
		
	}
	public void setName(String name) {
        this.name = name;
}
	public double getSalary(){
		  return salary;
	 } 
	 public void setSalary(double salary) {
		this.salary=salary;  
	 } 
	 public String getYear(){
		  return year;
	 } 
	 public void setYear(String year) {
		this.year= year;  
	 } 
	 public String getInsurance(){
		  return insurance;
	 } 
	 public void setInsurance(String insurance) {
		this.insurance= insurance;  
	 } 
	 
    }
