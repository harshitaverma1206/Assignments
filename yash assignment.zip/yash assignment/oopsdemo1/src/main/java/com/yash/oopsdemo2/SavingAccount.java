package com.yash.oopsdemo2;

public class SavingAccount extends Account {
	  
	    private double interest;

	    public SavingAccount(int acctNum, double interest) {
	        super(acctNum);
	        this.interest=interest;
	    }

	    public double getInterest() { 
	        double x= getBalance() + getBalance()*interest;
	        return x;
	    }
	    public void AddInterest (double interest) { 
	        double x = super.getBalance() * interest; 
	        super.deposit(x);
	    }
	    public String toString() {
	        return super.toString()+" Interest : " + interest; 
	    }
	}

