package com.yash.oopsdemo1;
// author calculate the no.of books
public class Book {
 
String  name;
 double  price;
 String  type;
 

	    public String getBook_Name() {
	        return name;
	    }

	    public void setBook_Name(String name) {
	    	name = name;
	    }
	    public double getBook_Price() {
	        return price;
	    }

	    public void setBook_Price(double price) {
	    	price = price;
	    }
	    public String getBook_Type() {
	        return type;
	    }

	    public void setBook_Type(String type) {
	    	type = type;
	    }
    
	  public static void main(String args[]) {
	    			
	    			Book b=new Book();
	    			b.setBook_Name("hgfsd");
	    		    b.setBook_Price(123);
	    		    b.setBook_Type("1234");
	    		   
	    		   System.out.println("Book_Name:" +b.getBook_Name());
	    		   System.out.println("Book_Price:" +b.getBook_Price());
	    		   System.out.println("Book_Type:" +b.getBook_Type());
	    		   
	    		   
	  }}
	    	     	

