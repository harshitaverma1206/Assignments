package com.yash.oopsdemo1;
//using 
class Person1{
	public void render()
	{
		System.out.println("rendering person");
	}
class Son extends Person1{
	public void render() {
		System.out.println("rendering son");
	}
}
class Father extends Person1{
	public void render() {
		System.out.println("rendering father");
	}
}
class Brother extends Person1{
	public void render(){
		System.out.println("rendering brother");
	}
}
}

 class Person{
	public static void main(String args[]) {
		Son s1=new Son();
		s1.render();
		Father s2=new Father();
		s2.render();
		Brother s3=new Brother();
		s3.render();
	}
}

