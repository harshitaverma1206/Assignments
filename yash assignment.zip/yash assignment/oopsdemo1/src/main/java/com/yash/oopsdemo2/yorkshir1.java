package com.yash.oopsdemo2;

public class yorkshir1 extends Yorkshire   {
	public static void main(String args[]) {
		Yorkshire  obj=new Yorkshire ();
		Yorkshire .averagebreed();
	}
	
	
			
}
