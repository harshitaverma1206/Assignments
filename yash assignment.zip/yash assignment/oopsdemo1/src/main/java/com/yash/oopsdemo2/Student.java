package com.yash.oopsdemo2;

import java.sql.Array;

public class Student {

	String name;
	int age;
    String address;

public Student() {
	String name = "unknown";
	int age = 0;
	String address="not available";
}

void setinfo(String nam, int ag){
	 name=nam;
	 age=ag;
	 System.out.println("Name:"+name);
	 System.out.println("Age:"+age);
	 
	 
}
void setinfo(String nam,int ag,String adre){
	name=nam;
	 age=ag;
	 adre=address;
}
public static void main(String s[])
{
    Student students[] = new Student[5];

    students[0] = new Student();
    students[0].name = "Rajesh";
    students[0].age = 45;
    students[0].address = "sai road";

    students[1] = new Student();
    students[1].name = "Suresh";
    students[1].age = 35;
    students[1].address = "narol road";

    students[2] = new Student();
    students[2].name = "Ramesh";
    students[2].age = 15;
    students[2].address = "highway road";
    
    students[3] = new Student();
    students[3].name = "kartik";
    students[3].age = 25;
    students[3].address = "highway road";
    
    students[4] = new Student();
    students[4].name = "soha";
    students[4].age = 35;
    students[4].address = "highway road";
    
    for(int i = 0; i < students.length; i++)
    {
        System.out.println( students[i].name + "  " + students[i].age + "   " + students[i].address +  " address." );
    }



}
}

	 

	    
	

