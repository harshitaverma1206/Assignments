package com.yash.oopsdemo1;
class Build {   //using encapsulation
	String city;
    int num;
    String paper;
    double price;
    public String getCity() {
        return city;
  }
  
 public void setCity(String city) {
         this.city = city;
 } 

 public int getNum() {
        return num;
 }
  
 public void setNum(int num) {
      this.num = num;
 }
  
 public String getPaper() {
         return paper;
 }
  
  public void setPaper(String paper) {
     this.paper = paper;
 }
 public double getPrice(){
	  return price;
 } 
 public void setPrice(double price) {
	this.price=price;  
 } 
 public static void main(String [] args){

	 Build obj= new Build();

	    obj.setCity("Indore");
	    obj.setNum(12);
	    obj.setPaper("Sign");
	    obj.setPrice(213124);
  
       System.out.println(obj.getCity());
       System.out.println(obj.getNum());
       System.out.println(obj.getPaper());
       System.out.println(obj.getPrice());
  
     }
 }


