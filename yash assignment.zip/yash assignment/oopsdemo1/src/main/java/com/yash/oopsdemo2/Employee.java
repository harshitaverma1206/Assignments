package com.yash.oopsdemo2;
//using inheritance
class Employee extends Person {
	public static void main(String [] args){

		 Person obj= new Person();

		    obj.setName("Jhon");
		    obj.setSalary(12088);
		    obj.setYear("2009");
	        obj.setInsurance("82684");
	       System.out.println("Name:" +obj.getName());
	       System.out.println("Salary:" +obj.getSalary());
	       System.out.println("Year:" +obj.getYear());
	       System.out.println("Insurance:" +obj.getInsurance());
	  
	     }

}
