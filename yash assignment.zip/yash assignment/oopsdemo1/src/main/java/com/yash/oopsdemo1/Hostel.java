package com.yash.oopsdemo1;

public class Hostel {
  int id;
  String name;
  String section;
  public int getId() {
	  return id;
  }
  public void setId(int id) {
	this.id=id;  
  }
  public String getName() {
	  return name;
  }
  public void setName(String name) {
	this.name=name;  
  }
  public String getSection() {
	  return section;
  }
  public void setSection(String section) {
	this.section=section;  
  }
  
  public static void main(String args[]) {
		
		Hostel h=new Hostel();
		h.setId(1);
	    h.setName("jhon");
	    h.setSection("b");
	   
	   System.out.println("Id:" +h.getId());
	   System.out.println("Name:" +h.getName());
	   System.out.println("Section:" +h.getSection());
	   
	   h.setId(2);
	    h.setName("denny");
	    h.setSection("a");
	   
	   System.out.println("Id:" +h.getId());
	   System.out.println("Name:" +h.getName());
	   System.out.println("Section:" +h.getSection());
	   
	}}
  


