
public class NumbertoString {
	double num;
	public double getNum() {
		return num;
	}
    public void setNum(int i) {
    	this.num=num;
    }
    void  numberOutputInString() {
    	String House;
    }
    public static void main(String args[]) {
    	NumbertoString n=new NumbertoString();
    	n.setNum(12);
    	System.out.println("Num:" +n.getNum());
    }
}
