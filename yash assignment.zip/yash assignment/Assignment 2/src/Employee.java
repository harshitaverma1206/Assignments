
 class Employee {
	
	public static void main(String args[]) {
		String firstname="pankaj";
		String lastname="Sharma";
		String company="yash";
		String role="trainer";
		char ch1 = firstname.charAt(0);
		char ch2 = firstname.charAt(1);
		
		char ch3 = lastname.charAt(0);
		char ch4 = lastname.charAt(1);
			
		char ch5 = company.charAt(0);
		char ch6 = company.charAt(1);
			
		char ch7 = role.charAt(0);
		char ch8 = role.charAt(1);
			
		System.out.println("Character at 0 and 1 index is: "+ch1 +ch2 +ch3 +ch4 +ch5 +ch6 +ch7 +ch8);
	}
}
