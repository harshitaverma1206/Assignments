public class Stringdemo {
  String input;  
 
  public Stringdemo() {
	 
    input="hello"; 
	 
  }
  public String getinput() {
      return input;
  }
  public String toString() {
      return "Required Data: {Name:"   +getinput()+"}";
  }
  public static void main(String[] args) {
	  Stringdemo  myObj = new Stringdemo (); 
    System.out.println(myObj.input); 
  }
}
class Stringdemotest{
	void RequiredData() {
		System.out.println("input");
	}
}
	 
 

	

