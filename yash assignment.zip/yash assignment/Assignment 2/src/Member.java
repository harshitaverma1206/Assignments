
 class Member1 {

		String firstname;
		String lastname;
		String email;
		String password;
		String role;

		
		public String getfirstname() {
	        return firstname;
	    }
	    public void setfirstname(final String firstname) {
	        this.firstname = firstname;
	    }
	    
	    
	    public String getlastname() {
	        return lastname;
	    }
	    public void setlastname(final String lastname) {
	        this.lastname = lastname;
	    }
		
	    
	    public String getemail() {
	        return email;
	    }
	    public void setemail(final String email) {
	        this.email = email;
	    }
	
	    

	    public String getpassword() {
	        return password;
	    }
	    public void setpassword(final String password) {
	        this.password = password;
	    }
	    

	    public String getrole() {
	        return role;
	    }
	    public void setrole(final String role) {
	        this.role = role;
	    }

	    
	    public String toString() {
	        return "Member Detail: {Name: " + getfirstname() +" " + getlastname() + ", Email: " + getemail()+ ", Password: " + getpassword()+", Role: " + getrole() + "}";
	    }
}

 
 
 public class Member {
	    public static void main(String[] args) {
	 
	    	
	        final Member1 showMemberDetail = new Member1();
	        
	        showMemberDetail.setfirstname("Pankaj");
	        showMemberDetail.setlastname("Sharma");
	        showMemberDetail.setemail("sharma.pankaj@yash.com");
	        showMemberDetail.setpassword("12345");
	        showMemberDetail.setrole("Trainer");
	        
	        System.out.println(showMemberDetail.toString());
	    }
	}
