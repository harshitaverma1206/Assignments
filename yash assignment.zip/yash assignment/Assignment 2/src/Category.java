
 class Category1 {
	 String id;
	 String name;
	 String createDate;
	 
	 public String getid() {
	        return id;
	    }
	    public void setid(final String id) {
	        this.id = id;
	    }
	    public String getname() {
	        return name;
	    }
	    public void setname(final String name) {
	        this.name = name;
	    }
		
	    
	    public String getcreateDate() {
	        return createDate;
	    }
	    public void setcreateDate(final String createDate) {
	        this.createDate = createDate;
	    }
	    public String toString() {
	        return "CategoryDetail: {id: " + getid() +" ,  Name: " + getname()+ ", createDate: " + getcreateDate()+ "}";
	    }

}
 public class Category {
	    public static void main(String[] args) {
	 
	    	
	        final Category1 showCategoryDetail = new Category1();
	        
	        showCategoryDetail.setid("101");
	        showCategoryDetail.setname("core_java");
	        showCategoryDetail.setcreateDate("31-01-\r\n"+ "2017");
	        
	        
	        System.out.println(showCategoryDetail.toString());
	    }
	}

