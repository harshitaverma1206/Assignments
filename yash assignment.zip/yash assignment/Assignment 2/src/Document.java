class Docum {
 
    private String title;
    private String filepath;
    
    public String gettitle() {
        return title;
    }
    public void settitle(final String title) {
        this.title = title;
    }
    public String getfilepath() {
        return filepath;
    }
    public void setfilepath(final String filepath) {
        this.filepath = filepath;
    }
    public String toString() {
        return "Document Information: {title: " + gettitle() + ", filepath: " + getfilepath() +  "}";
    }
}

public class Document {
    public static void main(String[] args) {
 
    	
        final Docum showDocumentInformation = new Docum();
        
        showDocumentInformation.settitle("java basics");
        showDocumentInformation.setfilepath("c:/document/corejava/basics/introduction.pdf}");
        
        System.out.println(showDocumentInformation.toString());
    }
}