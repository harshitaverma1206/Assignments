package com.yash.tdddeom;
import java.io.*;
import java.io.FileOutputStream;
//write string data
public class FileDemo6 {
	public static void main(String args[]) throws Exception{
		try{FileOutputStream f= new FileOutputStream("C:\\\\Users\\\\ankit\\\\eclipse-workspace\\\\tdddeom\\\\doc.1txt");
		String s="hello how are you";
		//converting string in to byte
	    byte b[]=s.getBytes();
	    f.write(b);
	    f.close();
	 System.out.println("data is succsess");
	}
catch(Exception e) {
		System.out.println(e);	
	}
}
}


