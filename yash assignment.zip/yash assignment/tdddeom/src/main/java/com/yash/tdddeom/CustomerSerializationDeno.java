package com.yash.tdddeom;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.IOException;
import java.io.ObjectInputStream;
//using serialization
public class CustomerSerializationDeno  {
   public static void main(String args[])throws IOException {
	   int a=1234;
       FileOutputStream fout=new FileOutputStream("C:\\Users\\ankit\\eclipse-workspace\\tdddeom\\doc.1txt"); {
       ObjectOutputStream os=new ObjectOutputStream(fout);	   
       os.writeObject(a);
       System.out.println("data is serialized");
       os.flush();
  
       }
   }
}
