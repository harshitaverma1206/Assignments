package com.yash.tdddeom;

import java.io.File;
import java.io.FileReader;

public class FileDemo1 {
	public static void main(String args[]) {
		try{
			File f=new File("C:\\Users\\ankit\\eclipse-workspace\\tdddeom\\doc.1txt");
			int i;
			FileReader f1=new FileReader(f);
			while((i=f1.read())!=-1)
			System.out.println((char)i);
			
		}
		
		catch(Exception e) {
			System.out.println(e);
		}
	}

}
