package com.yash.tdddeom;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
 class A implements Serializable {
	int id;
	String hello;
	double price;
	//creating constructor
	A(int id,String hello,double price){
		this.id=id;
		this.hello=hello;
		this.price=price;
		}
	}
 public class FileDemo10{
	 public static void main(String args[]) throws Exception{
		 A a=new A(12,"hello",123);
		 //data serialization
		 FileOutputStream fout=new FileOutputStream("C:\\\\Users\\\\ankit\\\\eclipse-workspace\\\\tdddeom\\\\doc.1txt"); 
		 ObjectOutputStream bout=new ObjectOutputStream(fout);
		 bout.writeObject(a);
		 System.out.println("data is serialized");
		 
		 
		 //  d-serialization
		 FileInputStream f=new FileInputStream("C:\\Users\\ankit\\eclipse-workspace\\tdddeom\\doc.1txt");
		 ObjectInputStream o=new ObjectInputStream(f);
		 A b=(A)o.readObject();
		 System.out.println( " ID :" + b.id + " String" :  + b.hello + " Double "  + b.price);
		 
		 
		 
	 } 
 }

