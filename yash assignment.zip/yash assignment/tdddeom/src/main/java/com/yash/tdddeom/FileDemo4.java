package com.yash.tdddeom;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
public class FileDemo4 {
	public static void main(String args[]) throws Exception {
		File f=new File("C:\\Users\\ankit\\eclipse-workspace\\tdddeom\\doc.1txt");
	try(FileInputStream fin=new FileInputStream("C:\\\\Users\\\\ankit\\\\eclipse-workspace\\\\tdddeom\\\\doc.1txt");
	    BufferedInputStream bin=new BufferedInputStream(fin);
		
		FileOutputStream fout=new FileOutputStream(f);
			BufferedOutputStream bout=new BufferedOutputStream(fout);)
	{
	  String s="hello gyz how are you,";
	  byte b[]=s.getBytes();
	  bout.write(b);
	  int x=0;
	  while((x=bin.read())!=-1)
		  System.out.print((char)x);
	}
	catch(Exception e) {
	  System.out.println(e);	
	}
	}
}
