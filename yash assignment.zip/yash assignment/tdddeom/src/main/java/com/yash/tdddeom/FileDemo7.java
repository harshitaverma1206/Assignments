package com.yash.tdddeom;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class FileDemo7 {
	public static void main(String args[]) throws FileNotFoundException {
		FileOutputStream f1=new FileOutputStream("C:\\Users\\ankit\\eclipse-workspace\\tdddeom\\doc.1txt");
		FileInputStream f=new FileInputStream("C:\\Users\\ankit\\eclipse-workspace\\tdddeom\\doc.1txt");
		try {
			String s="Name,id,password,";
			//converting
            byte b[]=s.getBytes();
            f1.write(b);
            f1.close();
            System.out.println("data is filling");
            int i;
    		while((i=f.read())!=-1)
    			System.out.println((char)i);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
}
