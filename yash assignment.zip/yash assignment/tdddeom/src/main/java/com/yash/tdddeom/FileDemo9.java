package com.yash.tdddeom;
import java.io.*;
//using buffered input
public class FileDemo9 {
	public static void main(String args[]) {
		try{
			FileInputStream fin= new FileInputStream ("C:\\Users\\ankit\\eclipse-workspace\\tdddeom\\doc.1txt");
		    BufferedInputStream bin=new BufferedInputStream(fin);
			int i;
		    while((i=bin.read())!=-1);
			{
			System.out.println((char)i);
		   }
		 
		  
	}catch(Exception e){
			System.out.println(e);
		}
		
}
}



