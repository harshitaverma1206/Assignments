package com.yash.tdddeom.util;

public class StringCalculator {
 public int add(int i,int j) {
	 return i+j;
 }
}
