package com.yash.tdddeom.util;

public class PizzaApp {
  public static void main(String args[]) {
	  PizzaSize[]s=PizzaSize.values();
	  for(PizzaSize s1:s)
	  {
		  System.out.println("Pizza Size Name"+s1+"Pizza Size"+s1.getSize());
	  }
	  
  }
}
