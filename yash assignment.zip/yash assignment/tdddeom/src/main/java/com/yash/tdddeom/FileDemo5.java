package com.yash.tdddeom;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
//write data into byte
public class FileDemo5 {
	public static void main(String args[]) throws FileNotFoundException {
	FileOutputStream f=new FileOutputStream("C:\\Users\\ankit\\eclipse-workspace\\tdddeom\\doc.1txt");	
	try {
		f.write(654);
		f.close();
		System.out.println("success");
	}
	catch(Exception e) {
		System.out.println(e);
	}
	}
	}
		