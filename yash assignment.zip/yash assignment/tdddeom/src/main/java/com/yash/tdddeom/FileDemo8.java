package com.yash.tdddeom;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Scanner;
public class FileDemo8 {
	public static void main(String args[]) throws FileNotFoundException {
		try{
	         String hello;    
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a data in a file");
	        hello=sc.nextLine();
	        FileOutputStream f= new FileOutputStream("C:\\Users\\ankit\\eclipse-workspace\\tdddeom\\doc.1txt");
	        f.write(hello.getBytes());	        
		}
		catch(Exception e) {
			 System.out.println(e);
		}
	}}

