package com.yash.tdddeom;
import java.io.*;

import java.io.FileInputStream;
public class FileDemo {
	public static void main(String args[]) {
		try{
			File f=new File("doc1.txt");
			System.out.println("file name" +f.getName()+ "file path" +f.getPath()+ "file parent " +f.getParent());
			FileInputStream f1= new FileInputStream(f);
			int i;
		while((i=f1.read())!=-1)
			System.out.println((char)i);
		}
	catch(Exception e) {
		System.out.println(e);
	}

	}
	}
	