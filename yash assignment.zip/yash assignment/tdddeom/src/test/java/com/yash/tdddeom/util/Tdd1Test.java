package com.yash.tdddeom.util;

import static org.junit.Assert.*;

import org.hamcrest.Matcher;
import org.junit.Test;

public class Tdd1Test {

	@Test
	public void testEvenOddNumber(){
		Tdd1 a=new Tdd1();
	    assertEquals("10 is a even number", true, a.isEvenNumber(10));
    }

	
	}


