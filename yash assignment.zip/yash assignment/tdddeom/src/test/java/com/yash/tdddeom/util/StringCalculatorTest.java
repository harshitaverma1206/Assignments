package com.yash.tdddeom.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringCalculatorTest {
	StringCalculator c=new StringCalculator();

	@Test
	public void test_AddMethod_GivenValue_ShouldReturn_Addition() {
		int expected=4;
		int actual=c.add(2,2);
		assertEquals(expected,actual);
		
	}

}
