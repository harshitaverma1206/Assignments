package com.yash.tdddeom.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class Tdd2Test {

	@Test
	public void testEvenOddNumber() {
		Tdd2 b=new Tdd2();
		assertEquals("9 is a odd number", true, b.isoddNumber(9));
	}

}
