package com.yash.tdddeom.util;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ StringCalculatorTest.class, StringCalculatorTest1.class })
public class StringTest {

}
