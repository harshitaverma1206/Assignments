package com.yash.tdddeom.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringCalculatorTest1 {
	StringCalculator c=new StringCalculator();
	@Test
	public void test_AddMethod_GivenValue_ShouldReturn_Addition() {
		int expected=3;
		int actual=c.add(1,2);
		assertEquals(expected,actual);
	}
}
