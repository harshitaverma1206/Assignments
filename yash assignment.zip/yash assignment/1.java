                                                   assignments
technical question
 simple interest
class Demo
{
 public static void main (string args[])
{
 int p=5000;
 int r=6;
 int n=3;
 float result=p*r*n/100;
 System.out.println("the final amount is"+result);
}

}



 
Q.3 difference b/w jdk and jre and Jvm
jdk-(java development kit)
The Java Development Kit (JDK) is a software development environment used for developing Java applications and applets. 
It includes the Java Runtime Environment (JRE), an interpreter/loader (Java), a compiler (javac), an archiver (jar), 
a documentation generator (Javadoc) and other tools needed in Java development.
