package com.yash.collection;
import java.util.*;
public class ArrayList1 {
	
	 
	    public static void main(String []args) {
	 
	 
	 
	    ArrayList<String> arrlstStr = new ArrayList<String>(); //Declaring ArrayList
	 
	 
	 
	        arrlstStr.add("hello");
	 
	        arrlstStr.add("how");
	 
	        arrlstStr.add("are");
	 
	        arrlstStr.add("you");
	 
	  //applying size method
	  System.out.println("the Arraylist size is:" +arrlstStr.size());
	//Displaying array list
	  for (int i=0;i<arrlstStr.size();i++){
	 
	 System.out.println(arrlstStr.get(i));
	 
	 
	 }
	 
	    }            
	 
	}


