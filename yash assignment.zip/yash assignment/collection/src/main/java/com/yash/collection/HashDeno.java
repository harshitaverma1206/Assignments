package com.yash.collection;

import java.util.HashSet;
import java.util.Iterator;

public class HashDeno {
	public static void main(String[] args)
    {
        HashSet<String> h = new HashSet<String>();
  
        // Adding elements into HashSet using add()
        h.add("jhon");
        h.add("andrew");
        h.add("thoms");
        h.add("aderson"); // adding duplicate elements
  
        // Displaying the HashSet
        System.out.println(h);
        System.out.println("List contains andrew or not:"
                           + h.contains("andrew"));
  
        // Removing items from HashSet using remove()
        h.remove("thoms");
        System.out.println("List after removing thoms:"
                           + h);
        // Checking for the empty set
        System.out.println("Is the set empty: " + h.isEmpty());
        
        // checking the size
        System.out.println(" set size: " + h.size());
        
        // copy with clone()
        HashSet<String>cloneset=new HashSet<String>();
        cloneset = (HashSet)h.clone();  
        System.out.println("The new clone set elements: " + cloneset);  
        
        
        // Iterating over hash set items
        System.out.println("Iterating over list:");
        Iterator<String> i = h.iterator();
        while (i.hasNext())
           System.out.println(i.next());
    }
}

