package com.yash.collection;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayList5 {
	//using get and set 
	public static void main(String args[]) {
		ArrayList<String> monthList=new ArrayList<String>(Arrays.asList("january","fabuary","march","april"));
		
		System.out.println("monthlist are:"+monthList);
	//using get
		System.out.println("list at 0 and 1 index:"+monthList.get(0)+" "+monthList.get(1));
	//using set
		monthList.set(1,"june");
		System.out.println("after replacing :"+monthList.get(1));
		System.out.println("after replacing :"+monthList);
		
	}

}
