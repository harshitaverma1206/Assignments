package com.yash.collection;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayList7 {
	public static void main(String args[]) {
		ArrayList<Integer> numberList=new ArrayList<Integer>(Arrays.asList(1,2,3,4,5,6,7));
        System.out.println("list is:"+numberList);
      //declare array
        Integer myArray[] = new Integer[numberList.size()]; 
        //use toArray method to convert ArrayList to Array
        myArray = numberList.toArray(myArray); 
        //print the Array
        System.out.println("Array from ArrayList:" + Arrays.toString(myArray)); 
	}}
