package com.yash.collection;
import java.util.*;
import java.util.HashMap;

public class HashMapDemo {
	public static void main(String[] args) {
		HashMap<Integer,student>h=new HashMap<Integer,student>();
		student n1=new student(1,"jhon");
		student n2=new student(2,"andrew");
		student n3=new student(3,"jhony");
		
		//we use put method for inserting elements
		h.put(1,n1);
		h.put(2,n2);
		h.put(3,n3);
		System.out.println(h);

		for (Map.Entry mapElement : h.entrySet()) {
            int key
                = (int)mapElement.getKey();
  
            // Finding the value
            String value = (String)mapElement.getValue();
  
            System.out.println(key + " : "+ value);
	    
	    
	
	}

}
}
