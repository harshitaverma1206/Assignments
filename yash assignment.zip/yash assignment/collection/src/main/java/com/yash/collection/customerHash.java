package com.yash.collection;
import java.util.Iterator;
import java.util.HashSet;
class Product{
	int id;  
	String name;  
	int quantity;
	int expdate;
	
	public Product(int id, String name, int quantity,int expdate) {  
	    this.id = id;  
	    this.name = name;  
	    this.expdate=expdate;  
	    this.quantity = quantity;  
	}

	}  
public class customerHash {
	
	public static void main(String []args) {
		HashSet<Product> h = new HashSet<Product>();
		 
		//creating list
		Product c1=new Product(1,"jhon",25,123);
		Product c2=new Product(2,"rock",17,100);
		Product c3=new Product(3,"jhon",21,125);
        
		//adding Customer to hash set
        h.add(c1);
        h.add(c2);
        h.add(c3);
        
       // removing specific one 
        h.remove(c1); 
        
        // checking value contains or not in the set 
        System.out.println(h.contains(c3));
        
        // getting the size 
        System.out.println("the size of set is:"+h.size());
        
        for(Product c:h){  
            System.out.println(c.id+" "+c.name+" "+c.expdate+" "+c.quantity);  
               
             }  
        }

	}


