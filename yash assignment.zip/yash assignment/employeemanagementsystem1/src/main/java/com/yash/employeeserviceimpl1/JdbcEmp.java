package com.yash.employeeserviceimpl1;

import com.yash.service1.jdbc1;

public class JdbcEmp implements jdbc1{

	@Override
	public void getAllemp() {
		// TODO Auto-generated method stub
		
	}

	

}
