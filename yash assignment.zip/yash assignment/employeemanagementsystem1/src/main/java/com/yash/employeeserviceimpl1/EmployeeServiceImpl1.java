package com.yash.employeeserviceimpl1;

import java.util.*;  
import java.util.stream.Collectors;

import com.yash.model1.EmployeeModel;
//import com.yash.model1.EmployeeRecord;
import com.yash.service1.employeeservice1;


/**
 * This is a service  class to provide record of employee
 *
 * @author harshita
 */
public class EmployeeServiceImpl1 implements employeeservice1{

public static ArrayList<EmployeeModel> createListofemployee(){
		
		ArrayList<EmployeeModel> emp = new ArrayList<EmployeeModel>();
		emp.add(new EmployeeModel(1,"jhon",9000,"pune","cs"));
		emp.add(new EmployeeModel(2,"andrew",436257,"mumbai","ec"));
		emp.add(new EmployeeModel(3,"andy",50000,"indore","el"));
		emp.add(new EmployeeModel(4,"zoya",576755,"heydrabad","account"));
		return emp;
			
		}
		
				
		public void getAllEmployee1() {
			// TODO Auto-generated method stub
			ArrayList<EmployeeModel>list=createListofemployee();
			System.out.println(list);
			
			Iterator value = list.iterator();
			  
	        // Displaying the values after iterating through the iterator
	        System.out.println("The iterator values are: ");
	        while (value.hasNext()) {
	            System.out.println(value.next());
	        System.out.println("---------------------------");
	        }
		}
		
public void getEmployeeById() {
			// TODO Auto-generated method stub
	ArrayList<EmployeeModel>list=createListofemployee();
	Scanner	sc=new Scanner(System.in);	
	System.out.println("enter id to search");
			try{int id = sc.nextInt();
			System.out.println(list.stream().filter(e->e.id==id)
					.map(e->e.toString())
					.collect(Collectors.toList()));	}
			catch(Exception e) {
				System.out.println(e);
			}
	System.out.println("---------------------------");
			
			 
		}
public void getEmployeeByName() {
	ArrayList<EmployeeModel>list=createListofemployee();
	Scanner	sc1=new Scanner(System.in);	
	System.out.println("enter name to search");
			 String name = sc1.nextLine();
			System.out.println(list.stream().filter(e->e.name.equals(name))
					.map(e->e.toString())
					.collect(Collectors.toList()));	
			
			   
	System.out.println("---------------------------");
}

public void getEmployeeBySalary() {
	ArrayList<EmployeeModel>list=createListofemployee();
	Scanner	sc=new Scanner(System.in);	
	System.out.println("enter salary to search");
			int salary = sc.nextInt();
			System.out.println(list.stream().filter(e->e.salary==salary)
					.map(e->e.toString())
					.collect(Collectors.toList()));	
		
	System.out.println("---------------------------");
}

public void getEmployeeByCity() {
	ArrayList<EmployeeModel>list=createListofemployee();
	Scanner	sc1=new Scanner(System.in);	
	System.out.println("enter address to search");
			 String address = sc1.nextLine();
			System.out.println(list.stream().filter(e->e.address.equals(address))
					.map(e->e.toString())
					.collect(Collectors.toList()));	
			
			   
	System.out.println("---------------------------");
}

public void getEmployeeByDepartment() {
	// TODO Auto-generated method stub
	ArrayList<EmployeeModel>list=createListofemployee();
	Scanner	sc1=new Scanner(System.in);	
	System.out.println("enter department to search");
			 String department = sc1.nextLine();
			System.out.println(list.stream().filter(e->e.department.equals(department))
					.map(e->e.toString())
					.collect(Collectors.toList()));	
			 
			   
	System.out.println("---------------------------");
}


public void getHighestSalary() {
	ArrayList<EmployeeModel>list=createListofemployee();
	list.stream().filter(emp->emp.getSalary() > 10000).forEach(System.out::println);
	System.out.println("---------------------------");
}
public void getMinimumSalary() {
	ArrayList<EmployeeModel>list=createListofemployee();
	list.stream().filter(emp->emp.getSalary() < 10000).forEach(System.out::println);
	System.out.println("---------------------------");
}

		
public void getmenu() {
	//ArrayList<EmployeeRecord> c=new ArrayList<EmployeeRecord>();
	Scanner sc=new Scanner(System.in);
	Scanner sc1=new Scanner(System.in);
	int ch;
	
    do{

        System.out.println("1.GetEmployeeById");
        System.out.println("2.GetEmployeeByName");
        System.out.println("3.GetEmployeeBySalary");
        System.out.println("4.GetEmployeeByCity");
        System.out.println("5.GetEmployeeByDepartment");
        System.out.println("6.getHighestSalary");
        System.out.println("7. getMinimumSalary");
        //System.out.println("8.GetUpdate");
        System.out.println("Enter your choice");
        
    ch=sc.nextInt();
    switch(ch) {
    
    case 1:
    	
    	getEmployeeById();
    	break;
    	
    case 2:
    	
    	getEmployeeByName();
    	break;
    case 3:
    	
    	 getEmployeeBySalary();
    	break;
    	
    case 4:
    	
    	getEmployeeByCity();
    	break;
    	
    case 5:
    	
    	getEmployeeByDepartment();
    	break;
    	
    case 6:
    	
    	getHighestSalary();
    	break;
    	
    case 7:
    	
    	getMinimumSalary();
    	break;
    	
    	}
    } while(ch!=0);	

}
public void goodBaye()

{
   System.out.println(" Thank You");
   System.out.println("You Are Logged Out");

}

}



