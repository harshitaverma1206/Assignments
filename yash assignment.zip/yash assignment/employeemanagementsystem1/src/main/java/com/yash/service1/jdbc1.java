package com.yash.service1;

public interface jdbc1 {
	public void getAllemp();
	
}
