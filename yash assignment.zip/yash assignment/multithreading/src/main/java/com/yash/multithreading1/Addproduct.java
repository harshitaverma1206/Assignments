package com.yash.multithreading1;

public class Addproduct {
	int id=12;
	String color="red";	

public Addproduct(int id,String color) {
	this.id=id;
	this.color=color;
}
}