package com.yash.multithreading;

class adding implements Runnable{
	int a;
	int b;
//create constructor	
public adding(int a,int b) {
	this.a=a;
	this.b=b;
	
}	
	@Override
	public void run() {
		try {
		add(a,b);}
		catch(Exception e){
			System.out.println(e);
		}
	}
	public void add(int a, int b) {
		int sum=0;
		for(int i=a;i<=b;i++){
            sum = sum+ a;
        }
		System.out.println("Sum of "+a+" to "+ b+" numbers = "+sum);  
	}	
}
public class Tmulti1 {
	 public static void main(String[] args) {
		 Thread t1=new Thread(new adding(1,5));
		 Thread t2=new Thread(new adding(3,4));
		 Thread t3=new Thread(new adding(6,6));
		 Thread t4=new Thread(new adding(5,8));
		 t1.start();
		 t2.start();
		 t3.start();
		 t4.start();
		 
	 }
	

}
