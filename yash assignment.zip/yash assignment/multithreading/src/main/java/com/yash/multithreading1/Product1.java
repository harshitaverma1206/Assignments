package com.yash.multithreading1;

class Product extends Thread {
	public void run() {
		System.out.println("Get list");
		try {
			Thread.sleep(500);
		}
	  catch(Exception e) {
	  System.out.println(e);
  }
	class Addprduct extends Thread{
		
	public void run() {
		System.out.println("Add prroduct");
		try {
			Thread.sleep(500);
		}
	  catch(Exception e) {
	  System.out.println(e);
  }
		
	}
	
	}
	
	}
 class Product1 {
public void main(String args[]) {
	getlistofProduct s=new getlistofProduct();
}
	
}