package com.yash.multithreading;

public class Tmulti4 extends Thread{
	//join method
public void run(){  
		  for(int i=1;i<=5;i++){  
		   try{  
		    Thread.sleep(500);  
		   }catch(Exception e){System.out.println(e);}  
		  System.out.println(i);  
		  }  
		 }  
		public static void main(String args[]){  
			Tmulti4 t1=new Tmulti4();  
			Tmulti4 t2=new Tmulti4();  
			Tmulti4 t3=new Tmulti4();  
		 t1.start();  
		 try{  
		 t1.join();  
		 }catch(Exception e){
			 System.out.println(e);
			 }  
		  
		 t2.start();  
		 t3.start();  
		 }  
		}  


