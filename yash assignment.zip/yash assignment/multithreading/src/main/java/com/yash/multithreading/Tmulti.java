package com.yash.multithreading;
// creating by runnable interface
public class Tmulti extends Thread {
	
	public void run() {
		try {
			System.out.println( "thread is running or not:"+" "+Thread.currentThread().getId());
			}
		    catch(Exception e) {
			System.out.println(e);
			}
	}

public static void main(String args[]) {
	for(int i=1;i<=3;i++){
	Tmulti m=new Tmulti();
	Thread t=new Thread(m);
	t.start();
	System.out.println(t.getName()); }    
}
}
