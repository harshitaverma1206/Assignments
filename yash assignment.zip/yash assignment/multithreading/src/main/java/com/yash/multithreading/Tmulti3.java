package com.yash.multithreading;

public class Tmulti3 extends Thread {
	
 public void run()
	 {  
	   for(int i = 1; i <= 5; i++)
	    {  
	      System.out.println(Thread.currentThread().getName() + " is running and i = "+i);  
	    try 
		   {
	    	// Sleep the current thread for 2 second
		     Thread.sleep(2000); 
		     
		   } 
	    catch (InterruptedException e) 
		{
		    System.out.println(e);
		}
	    //e.printStackTrace
	     }
	  }  
	  public static void main(String args[])
	  {  
		 Tmulti3 thread1 = new Tmulti3 ();  
		 thread1.setName("Thread1");
		 Tmulti3 thread2 = new Tmulti3 ();
		 thread2.setName("Thread2");
			 
		 thread1.start();
		 thread2.start();  
	   }  
	
}

