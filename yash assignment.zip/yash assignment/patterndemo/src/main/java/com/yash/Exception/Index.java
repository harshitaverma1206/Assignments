package com.yash.Exception;
import java.util.ArrayList;
import java.util.Scanner;
public class Index extends Exception {
   
public static void main(String[] args) {
       
	String [] names= {"piya","tiya","jhon","tom","cat","toy","boy","joy","zoy","dog"};
	String integer;
try {
	System.out.println("Please, enter an integer from 1 to 10 to display a name");
	Scanner input= new Scanner(System.in);
	integer = input.nextLine(); 
	int i = Integer.parseInt(integer);
	i = i-1;
	System.out.println(names[i]);
	input.close();
	
}
	catch(ArrayIndexOutOfBoundsException e) {
		System.out.println(e);
	}

}
}

    

	



	

