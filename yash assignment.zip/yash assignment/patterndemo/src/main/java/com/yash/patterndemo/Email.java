package com.yash.patterndemo;
import java.io.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class Email {
	public static void main(String []args) {
		ArrayList<String>emails=new ArrayList<String>(); 
		emails.add("harsha@do.com");
		emails.add("ini@do.com");
		emails.add("@do.com");
		emails.add("har@docom");
		emails.add("12dsdn");
		String regex="^[A-za-z0-9+_.-]+@(.+)$";
		Pattern p=Pattern.compile(regex);
		for(String email:emails) {
		Matcher m=p.matcher(email);
		System.out.println(email+":"+m.matches()+"\n");
	}
}
}
		
