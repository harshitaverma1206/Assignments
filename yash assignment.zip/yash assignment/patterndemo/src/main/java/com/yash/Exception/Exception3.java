package com.yash.Exception;
//system exception
public class Exception3 {
	public static void main (String args[]) {
		//NullPointerException
       try { String a=null;
        System.out.println(a.charAt(0));
        }
       catch(NullPointerException e){
    	   System.out.println("NullPointerException");
       }
	//NumberFormatException
	try{int num=Integer.parseInt("harshita");
	System.out.println(":"+num);}
	catch(NumberFormatException e) {
		System.out.println("NumberFormatException");
	}
	finally {
		System.out.println("finally block is always excecuted");
	}
	}
	}
