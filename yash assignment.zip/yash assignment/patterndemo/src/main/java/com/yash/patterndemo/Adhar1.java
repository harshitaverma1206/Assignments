package com.yash.patterndemo;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Adhar1 {

	public static boolean isValidMobileNo(java.lang.String str) {
		  
		Pattern p=Pattern.compile("(0/9)?[7-9][0-9]{9}");
		Matcher m=p.matcher((CharSequence) str);
		return(m.find()&&m.group().equals(str));
	}
	
		public static void main(String[]args) {
			java.lang.String str="9800088899";
		
		if(isValidMobileNo(str)) 
			System.out.println("no.is valid");
		
		else 
			System.out.println("no.is invalid");
		}
		
}
		