package com.yash.Exception;
//using throw 
public class Exception4 {
 static void validate(int age) {
	 if(age<18) 
	throw new ArithmeticException("not valid");
	 else
		 System.out.println("valid");
 }
 public static void main(String args[]) {
	 validate(13);
	 System.out.println("working....");
 }
}
