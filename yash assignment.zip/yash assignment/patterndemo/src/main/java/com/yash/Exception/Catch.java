package com.yash.Exception;

import javax.security.auth.login.AccountException;

//multiple catches
public class Catch {
	public static void main(String args[]) {
		try {
			int a[]= {1,2,3,45};
			
	        System.out.println(a.length);
	        System.out.println(a[4]);
	        System.out.println(a[(Integer) null]);
			}
	catch(ArrayIndexOutOfBoundsException e) {
	System.out.println(e);
	}
    catch(ArithmeticException e) {
	System.out.println(e);
}
    catch(NullPointerException  e) {
    	System.out.println(e);
    }	
	}
}