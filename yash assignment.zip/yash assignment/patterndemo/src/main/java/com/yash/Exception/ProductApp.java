package com.yash.Exception;


import java.rmi.AccessException;
import java.util.ArrayList;

public class ProductApp {
	public static void main (String args[]) {
		  try{
			  int a[]= null;
		 System.out.println(a[1]);}
		  catch(NullPointerException e){
			  System.out.println("NullPointerException");
		  }
		  try{
			  int b[]= {12,2,3,4};
		  System.out.println(b[4]);}
		  catch(ArrayIndexOutOfBoundsException e){
			  System.out.println("ArrayIndexOutOfBoundsException...");
		  }
	}
	
	
}
