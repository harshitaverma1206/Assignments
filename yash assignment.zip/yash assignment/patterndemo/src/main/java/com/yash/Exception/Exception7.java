package com.yash.Exception;

public class Exception7 {
  public static void main(String args[]) throws Exception {
	  try{int[] testing = {0,1,3,4,5,6};
      String mark = "";
      for(int i=0;i<testing.length;i++)
      {
           //mark += testing[i]; //But this line works fine
         mark = testing[i]; /* This line doesn't work */
      }
      System.out.println(mark);
    }
	  catch(Exception e) {
		  System.out.println(e);
	  }
  }
}

