package com.yash.patterndemo;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class String {
	public static void main(String[]args) {
		String inputStr="one 9two4 three7 four1five";
		String regexStr="[0-9]+";
		Pattern p=Pattern.compile(regexStr);
		Matcher m=pattern.matcher(inputstr);
	}
    }

