package com.yash.patterndemo;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
public class Currency {
	public static void main(String[] args) {
		ArrayList emails = new ArrayList();
		emails.add("user@domain.com");
		emails.add("user@domain.co.in");
		emails.add("user1@domain.com");
		emails.add("user.name@domain.com");
		emails.add("user#@domain.co.in");
		emails.add("user@domaincom");
		emails.add("user#domain.com");
		emails.add("@yahoo.com");
		 
		java.lang.String regex = "^(.+)@(.+)$";
		 
		Pattern pattern = Pattern.compile(regex);
		 
		for(String email:emails){
		    Matcher matcher = pattern.matcher((CharSequence) email);
		    System.out.println(email +" : "+ matcher.matches());
	}
	}
}


        