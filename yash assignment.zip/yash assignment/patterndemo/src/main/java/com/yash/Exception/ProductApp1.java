package com.yash.Exception;

public class ProductApp1 {
	static void validate(){ 
	int id= 11;
	String name= "soha";
	double price=1100;
	
	if(id<1) 
		throw new ArithmeticException("not valid");
		 
	{
	
	if (price>1)
		throw new ArithmeticException("not valid");
	 else
		 System.out.println("valid");
	}

}
public static void main(String args[]) {
	 validate();
	 System.out.println("working....");
}}
