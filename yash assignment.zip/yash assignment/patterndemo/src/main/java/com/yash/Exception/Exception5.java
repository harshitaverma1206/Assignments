package com.yash.Exception;

import java.io.FileInputStream;

public class Exception5 {
	public static void readList() throws Exception{
		int i;
		FileInputStream f=new FileInputStream("C:\\Users\\ankit\\eclipse-workspace\\patterndemo\\src\\main\\java\\doc2");
		while((i=f.read())!=-1)
		System.out.println((char)i);
	}
public static void main(String args[]) throws Exception {
	readList();
}
}
