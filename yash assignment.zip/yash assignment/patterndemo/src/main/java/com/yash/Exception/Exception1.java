package com.yash.Exception;
//system exception
public class Exception1 {
	public static void main (String args[]) {
		String name="null";
		System.out.println(name.length());
		int num[]= {1,2,3,4,5,6};
		System.out.println(num[6]);
		
		} 

}
