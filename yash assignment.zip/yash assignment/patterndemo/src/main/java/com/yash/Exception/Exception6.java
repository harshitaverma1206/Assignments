package com.yash.Exception;

import java.io.FileInputStream;

public class Exception6 {
	public static void main (String args[]) {
		// file which is unavailable in drive
		try {
			 int i;
			FileInputStream f=new FileInputStream("c\\user\\demo.txt");
		    	while((i=f.read())!=-1)
		    		System.out.println((char)i);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		//empty file
		try {
			int i;
			FileInputStream f=new FileInputStream("C:\\Users\\ankit\\eclipse-workspace\\patterndemo\\src\\main\\java\\doc2");
		    	while((i=f.read())!=-1)
		    		System.out.println((char)i);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		}
	 }
	


