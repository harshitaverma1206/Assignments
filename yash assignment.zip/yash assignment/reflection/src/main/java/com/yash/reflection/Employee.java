package com.yash.reflection;
import java.lang.Class;
import java.io.Serializable;


 public class Employee  implements Serializable,Cloneable {
      private int id;
      private String name;
      private int salary;
       
       
       public Employee() {
    	   super();
       }
       public  Employee(int id,String name,int salary) {
    	   super();
    	   this.id=id;
    	   this.name=name;
    	   this.salary=salary;
       }
    	   public int getid(int id) {
    			  return id;
    		}
    		public void setid(int id) {
    			  this.id=id;
    		}
    		public String getName(String name) {
    			  return name;
    		}
    		public void setName(String name) {
    			  this.name=name;
    		}

   public static void main(String args[]) {

    	   Employee obj= new Employee();

    	 	     obj.setid(12);
        	     obj.setName("jhon");
    	    	     
    	    	  System.out.println(obj.getid(12));
    	          System.out.println(obj.getName("jhon"));
    	    	    
    	    	    
    	    	   }     
    	    	   }
    	 