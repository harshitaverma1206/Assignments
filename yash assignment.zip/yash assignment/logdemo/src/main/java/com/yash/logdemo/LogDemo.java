package com.yash.logdemo;

public class LogDemo {

}
