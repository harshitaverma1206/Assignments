package com.java.classdemos.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Concate {

	@Test
	 public void Concattest() {
		Calculator jhon=new Calculator();
		String result=jhon.Concat("helo","hii");
		assertEquals("helohii",result);
		
	}

}
