package com.java.classdemos.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	public void Addtest() {
		Calculator jhon=new Calculator();
		int result=jhon.add(100, 200);
		assertEquals(300,result);
	
		
	}	
	
   
}
