package Calculator1.java;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Test_StringCalculator {

	@Test
	public void test_StringCalculator_ForZero_ShouldReturnZero() {
		Calculator2 cal=new Calculator2();
		assertEquals(cal.calculate(""),0);
		
	}
	@Test
	public void test_StringCalculator_GivenSingleValue_ShouldReturnSingleValue() {
		Calculator2 cal=new Calculator2();
		assertEquals(cal.calculate("2"),2);
	}
	@Test
	public void test_StringCalculator_GivenTwoValueaDeliitedByComma_ShouldReturnSum() {
		Calculator2 cal=new Calculator2();
		assertEquals(cal.calculate(2,2),4);
	}
	@Test
	public void test_StringCalculator_GivenTwoValueaDeliitedByLine_ShouldReturnSum() {
		Calculator2 cal=new Calculator2();
		assertEquals(cal.calculate("2"+"\n"+"2"),4);
	
	}
}
