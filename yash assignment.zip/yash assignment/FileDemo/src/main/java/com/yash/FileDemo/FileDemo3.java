package com.yash.FileDemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileDemo3 {
	public static void main(String[] args) throws FileNotFoundException {
		File f=new File("C:\\Users\\ankit\\eclipse-workspace\\FileDemo\\src\\main\\java\\com\\yash\\FileDemo\\file2.txt");
		System.out.println("file name" +f.getName()+ "file path" +f.getPath()+ "file parent " +f.getParent()+"file length:" +f.length());
		try{FileInputStream f1=new FileInputStream(f);
		int i;
		while((i=f1.read())!=-1)
        System.out.println((char)i);
		
		}
	catch(Exception e) {
		System.out.println(e);
	}
}
}