package com.yash.FileDemo;

import java.io.File;
import java.io.IOException;

public class FileDemo9 {
	public static void main(String args[]) throws IOException {

	try{File directoryPath = new File("/FileDemo/src/main/java/com/yash/FileDemo/doc3.txt");
    //List of all files and directories
       File filesList[] = directoryPath.listFiles();
       System.out.println("List of files and directories in the specified directory:");
       for(File file : filesList) {
       System.out.println("File name: "+file.getName());
       System.out.println("File path: "+file.getAbsolutePath());
       System.out.println("Size :"+file.getTotalSpace());
       System.out.println(" ");
       }
    }
    catch(Exception e) {
    	System.out.println(e);
    	}
    
	
}
	}
