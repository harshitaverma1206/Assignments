package com.yash.FileDemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileDemo7 {
	public static void main(String args[]) throws IOException {
		File f=new File("C:\\Users\\ankit\\eclipse-workspace\\FileDemo\\src\\main\\java\\com\\yash\\FileDemo\\doc3.txt");
		boolean flag = f.setReadOnly();	
    	if (flag==true)
    	{
    	   System.out.println("File successfully converted to Read only mode!!");
    	}
    	else
    	{
    	   System.out.println("Unsuccessful Operation!!");
    	}
    	}
	}