package com.yash.FileDemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileDemo2 {
	public static void main(String[] args) throws FileNotFoundException {
		try{FileInputStream f=new FileInputStream("C:\\Users\\ankit\\eclipse-workspace\\FileDemo\\src\\main\\java\\com\\yash\\FileDemo\\company\\basicinfo.txt");
		int i;
		while((i=f.read())!=-1)
			System.out.println((char)i);
		}
	catch(Exception e) {
		System.out.println(e);}
	}

}
