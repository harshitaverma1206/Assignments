package com.yash.FileDemo;

import java.io.File;
import java.io.FileInputStream;

public class FileDemo6 {
	public static void main (String args[]) throws Exception{
		try{File f=new File("C:\\Users\\ankit\\eclipse-workspace\\FileDemo\\src\\main\\java\\doc3.txt");
		
		if(f.delete()){  
			System.out.println(f.getName() + " deleted");   //getting and printing the file name  
		}  
		else  
		{  
		System.out.println("failed");  
		} 
		
	}
		catch(Exception e) {
			System.out.println(e);
		}
		
		
		
		
	}

}
