package com.yash.arraydemo.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class Array3Test {

	@Test
		public void test_AddMethod_GivenValue_ShouldReturn_Exact() {
			int expected=5;
			Object actual;
			assertEquals(expected,5);
	}

}
