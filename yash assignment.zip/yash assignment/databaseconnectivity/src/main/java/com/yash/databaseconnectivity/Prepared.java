package com.yash.databaseconnectivity;
import java.sql.*;  
public class Prepared {
	
	public static void main(String args[]){  
	try{  
	Class.forName("com.mysql.cj.jdbc.Driver");  
	  
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");  
	  
	PreparedStatement stmt=con.prepareStatement("insert into products values(?,?)");  
	stmt.setInt(1,11203);//1 specifies the first parameter in the query  
	stmt.setString(2,"Ratan");  
	  
	int i=stmt.executeUpdate();  
	System.out.println(i+" records inserted");  
	  
	con.close();  
	  
	}catch(Exception e){ System.out.println(e);}  
	  
	}  
	}  


