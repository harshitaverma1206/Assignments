package com.yash.carmain;

public class Delar {
	package com.yash.carmain;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.SQLException;
	import java.util.Scanner;

	import org.apache.log4j.Logger;
	import org.apache.log4j.PropertyConfigurator;

	import com.yash.carserviceimpl.CarServiceImpl;

	public class DelarMain{
		
		
		static Logger logger=Logger.getLogger(CarServiceImpl.class);
		public static void main(String args[]) throws ClassNotFoundException, SQLException {
			Scanner sc=new Scanner(System.in);
			try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			
			System.out.println("Enter choice");
			System.out.println("insert record");
			System.out.println("update record");
			System.out.println("delete record");
			int choice = Integer.parseInt(sc.nextLine());
			switch(choice) {
			case 1:
				insertRecord();
				break;
				
			case 2:
				//update();
				break;
				
			case 3:
				//Delete();
				break;
			}
			
			}catch(Exception e) {
				System.out.println(e);
			}
			}
		
			public static void insertRecord() throws ClassNotFoundException, SQLException {
				PropertyConfigurator.configure("C:\\Users\\harshita.verma\\Documents\\workspace-spring-tool-suite-4-4.11.0.RELEASE\\databaseconnectivity\\src\\Resourses\\log.properties1"); 
				System.out.println("inside insert record");
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
				
				String sql="insert into delar1(reg_num,shop_name,owner_name)values(?,?,?)";
				PreparedStatement sta = con.prepareStatement(sql);
				Scanner sc=new Scanner(System.in);
				Scanner sc1=new Scanner(System.in);
				System.out.println("enter a number");
				 sta.setInt(1,sc.nextInt());
				
				System.out.println("enter a shopname"); 
				sta.setString(2,sc1.nextLine());
				
				System.out.println("enter a ownername");
				sta.setString(3,sc1.nextLine());
				//sta.setString(3,"susen");
				int i=sta.executeUpdate();  
				logger.info(i+" records inserted");
				
			}
	}
}
