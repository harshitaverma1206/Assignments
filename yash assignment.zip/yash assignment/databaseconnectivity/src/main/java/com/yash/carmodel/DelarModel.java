package com.yash.carmodel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DelarModel {
	
	 protected static int reg_num;
	 protected static String shop_name;
	 protected static String  owner_name;
	 

	 public void getDelarDetails() {
	
		 Scanner input=new Scanner (System.in);
		 System.out.println("enter regnumber");
		 reg_num=input.nextInt();
		 System.out.println("enter shopname");
		 shop_name=input.nextLine();
		 System.out.println("enter ownername");
		 owner_name=input.nextLine();
		 
	 }
	
}

}
