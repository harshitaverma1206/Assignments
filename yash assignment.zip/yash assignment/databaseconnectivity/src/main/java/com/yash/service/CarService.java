package com.yash.service;

public interface CarService {
public void getAllCar();
}
