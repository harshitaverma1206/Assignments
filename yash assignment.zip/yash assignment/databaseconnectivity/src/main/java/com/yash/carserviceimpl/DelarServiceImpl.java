package com.yash.carserviceimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.carmodel.DelarModel;

public class DelarServiceImpl extends DelarModel  {
	 public static void insertDelar() throws SQLException {
		   Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
		   String s="inserting in to cardetails(?,?,?,?);";
		   PreparedStatement st=con.prepareStatement(s);
		   st.setInt(1,reg_num);
		   st.setString(2,shop_name);
		   st.setString(4,owner_name);
		   st.execute();
		   System.out.println("record inserted successfully");
		   st.close();
		   		
		}
}
