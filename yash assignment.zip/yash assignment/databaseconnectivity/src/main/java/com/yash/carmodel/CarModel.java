package com.yash.carmodel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class CarModel {
	 int registrationnum;
	 String  ownername;
	 int engine;
	 String type;

	 public void getCarDetails() {
	
		 Scanner input=new Scanner (System.in);
		 System.out.println("enter registrationnum");
		 registrationnum=input.nextInt();
		 System.out.println("enter name");
		 ownername=input.nextLine();
		 System.out.println("enter engine");
		 engine=input.nextInt();
		 System.out.println("enter type");
		 type=input.nextLine(); 
	 }
	 public void insertCar() throws SQLException {
		   Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
		   String s="inserting in to cardetails(?,?,?,?);";
		   PreparedStatement st=con.prepareStatement(s);
		   st.setInt(1,registrationnum);
		   st.setString(2,ownername);
		   st.setInt(3,engine);
		   st.setString(4,type);
		   st.execute();
		   System.out.println("record inserted successfully");
		   st.close();
		   		
		}
}