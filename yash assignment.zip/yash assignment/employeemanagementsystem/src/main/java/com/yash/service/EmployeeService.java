package com.yash.service;

//creating interface for emplyoeeServiceimpl
public interface EmployeeService {
	
	public void getAllEmployee();
	public void getmenu();
	public void goodbye();
	public void getEmployeeById();
	public void getEmployeeByName();
	public void getEmployeeBySalary();
	public void getEmployeeByAddress();
}