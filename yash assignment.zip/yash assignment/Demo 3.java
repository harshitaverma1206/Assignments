                                  Assignments 

technical question:-
Q.1 find the simple interest
ANS:
 class Demo1
{
 public static void main (string args[])
{
 int p=5000;
 int r=6;
 int n=3;
 float si=p*r*n/100;
 System.out.println("the simple interest is"+si);
}

}


Q.2 find the simple interest(user input)
ANS: 
import java.util.*;
 class Demo2
{
 public ststic void main(string args[])
{
 Scanner sc=new Scanner(System.in);
 System.out.println("enter the amount");
 int p=sc.nextInt();
 System.out.println("enter the rate");
 int r=sc.nextInt();
 System.out.println("enter the time");
 int n=sc.nextInt();
 int si=p*r*n/100;
 System.out.println("the simple interest is"+si);
 
}

}

 
Q.3 difference b/w jdk and jre and Jvm
ANS:
jdk-(java development kit):-
The Java Development Kit (JDK) is a software development environment used for developing 
Java applications and applets. 
It includes the Java Runtime Environment (JRE), an interpreter/loader (Java), a compiler (javac), 
an archiver (jar), a documentation generator (Javadoc) and other tools needed in Java 

jre-(java runtime environment):-
JRE stands for “Java Runtime Environment” and may also be written as “Java RTE.” 
The Java Runtime Environment provides the minimum requirements for executing a 
Java application.
it consists of the Java Virtual Machine (JVM), core classes, and supporting files.

Jvm-(java virtual machine):-
Java Virtual machine(JVM) is a very important part of both JDK and JRE because it is 
contained or inbuilt in both. 
Whatever Java program you run using JRE or JDK goes into JVM and JVM is responsible 
for executing the java program line by line hence 
it is also known as interpreter.

Q.4 define (string args[])
ANS:
String[] args means an array of sequence of characters (Strings) that are passed to 
the "main" function. 
This happens when a program is executed.
Example:- 
when you execute a Java program via the command line: java MyProgram This is just a test. 
Therefore, the array will store: ["This", "is", "just", "a", "test"] 

Q.5 define System.out.println in java
ANS:-
 System:-
        it is a predefined class that provide access to the system.
 out:-
        it is a outputstream that is connected to the console.
 println:-
        it is used to display information on the screen.